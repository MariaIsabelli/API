export interface Casa{
    id?: number
    nomeCasa: string
    enderecoCasa: string
    qtddPessoas: string
}