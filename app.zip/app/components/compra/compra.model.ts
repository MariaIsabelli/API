export interface Compra{
    id?: number
    nome: string
    sobrenome: string
    email: string
    telefone: string
    faixaEtaria: number
    endereco: string
    numeroCasa: number
    cep: string
    numeroCartao: string
    nomeTitular: string
    dataVenc: string
    anoVenc: string
    cvv: number
    numeroParcelas: number
}