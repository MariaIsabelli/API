export interface Cadastro{
id?: number
usuario:string
senha: string
}