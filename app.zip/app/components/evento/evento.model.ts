export interface Evento{
    id?: number
    nomeSolicitante: string
    nomeEvento: string
    descricao: string
    data: string
    preco: number
    enderecoEvento: string
    quantidadeIngresso: number
    patrocinadorEvento: string
}